![DC](readme-resources/diabetes-banner.png)

## Deployed Web App
If you want to view the deployed model, then go to following links mention below: <br />
• GitHub: _https://github.com/anujvyas/Diabetes-Prediction-Deployment_ <br />
• Web App: _https://predicting-diabetes.herokuapp.com/_
